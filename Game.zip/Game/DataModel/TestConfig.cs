using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TestConfig : BaseConfig
{
    public int testInt;
    public float testFloat;
    public string testString;
    public Vector3 position;
    public GameObject prefab;
}

public class LevelConfig : BaseConfig
{
    public List<Vector3> points;
}

public class ThingConfig : BaseConfig
{
    public Type thingClass;
    public string prefab;
}

public class WindowConfig : BaseConfig
{
    public Type thingClass;
    public string prefab;
}
