using System;
using System.Collections;
using System.Reflection;
using System.Collections.Generic;


using UnityEditor;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.AddressableAssets;
using UnityEngine.ResourceManagement.AsyncOperations;

using Vocore;

public class Thing: IEventReciever
{
    private GameObject _obj;
    private ThingConfig _config;

    public GameObject Instance
    {
        get
        {
            return _obj;
        }
    }
    public void OnCreate(GameObject obj, ThingConfig config)
    {
        _obj = obj;
        Button btn1 = _obj.transform.Find("Button1").GetComponent<Button>();
        btn1.onClick.AddListener(()=>{

        });

        Button btn2 = _obj.transform.Find("Button2").GetComponent<Button>();
        btn1.onClick.AddListener(() =>
        {

        });
    }

    public void Update()
    {
        _obj.transform.Translate(Vector3.forward);
    }

    public void Tick()
    {

    }

    public void OnDestroy()
    {

    }

    private void Hit(int damage)
    {
        Debug.Log(damage);
    }
}

public class Reciever : IEventReciever
{
    public void OnCreate()
    {
        this.RegisterEvent<int>(GameTest.eventHit, Hit);
    }

    public void OnDestroy()
    {
        this.UnregisterEvent(GameTest.eventHit);
    }

    private void Hit(int damage)
    {
        Debug.Log(damage);
    }
}

public class GameTest : MonoBehaviour
{
    public static readonly EventId eventHit = EventGenerator.Generate("hit");
    public static readonly EventId eventHitHuge = EventGenerator.Generate("hit");

    TestConfig config;

    // Start is called before the first frame update

    void Start()
    {

        
        //     DatabaseLoader.Load();

        //     Thing thing = CreateThing("thing1");

        //     CameraTrace trace = Camera.main.GetComponent<CameraTrace>();
        //     trace.target = thing.Instance.transform;


        config = Database<TestConfig>.Get("lym");
        
        // Debug.Log(config.testFloat);

        // // var level = Database<LevelConfig>.Get("level1");

        // GameObject cube;

        // var load = Addressables.LoadAssetAsync<GameObject>("Cube");
        // cube = load.WaitForCompletion();

        // load.Completed += (AsyncOperationHandle<GameObject> obj)=>{
        //     cube = obj.Result;
        // };

        // foreach (var pos in level.points)
        // {
        //     GameObject instacne = GameObject.Instantiate(cube);
        //     instacne.transform.position = pos;
        // }

        Reciever reciever = new Reciever();
        reciever.OnCreate();


        reciever.SendEvent<int>(eventHit, 10);

        ObjectEventExtension.SendEvent<int>(reciever, eventHit, 10);

        reciever.OnDestroy();
    }

    // Update is called once per frame
    void Update()
    {

    }

    Thing CreateThing(string configName)
    {
        ThingConfig config = Database<ThingConfig>.Get(configName);

        Thing thing = Activator.CreateInstance(config.thingClass) as Thing;

        GameObject obj = Addressables.LoadAssetAsync<GameObject>(config.prefab).WaitForCompletion();
        GameObject instance = GameObject.Instantiate(obj);
        thing.OnCreate(instance, config);

        return thing;
    }
}
